PHP 7.3.4 Windows 源码移植版，2026-10-22。

目标规格：**Windows x64、NTS、VC15，面向 Windows Server 2019 的 PHP FastCGI 环境。**

这次重新从干净 PHP 7.3.4 源码出发，以 PHP 官方提交 `01a40e89fbfc499936e3b05888d8f00bfde886df` 为依据移植。核心采用官方的延迟 OOM、可失败分配、软硬内存限额及内部 UnwindExit 退出机制，并适配 PHP 7.3 的 C 类型、内存布局和 Windows 接口。

已纳入的改动包括：

- 分配器及字符串、数组、哈希表的可失败分配接口；失败时保留原对象，正确返回错误。
- VM 中断处理、未完成调用帧清理、异常展开；普通异常不能替换内部强制退出标记。
- cURL、JSON、XML/DOM/SimpleXML、SOAP、SPL、PCRE、多字节字符串、压缩、文件及流等配套路径的适配。
- 请求启动/关闭的状态复位、multipart 头过滤和解析失败后的清理。
- Session 上传进度功能保留：采用官方的受限反序列化方式，初始化期间不加载用户类、不执行对象唤醒/自定义反序列化，并保留原始自定义对象载荷以便写回。
- 加入官方新版已有的 `max_multipart_body_parts` 前置限制，以及 `memory_hard_limit_percent` 配置。

官方提交涉及的非测试代码按 111 个条目登记在 `source-port-mapping.json`：适配 PHP 7.3 的机制保持对应关系；PHP 8 独有的 Attributes、JIT、命名参数、SensitiveParameter、PhpToken、枚举、共享类名 CE 缓存槽等不凭空加入 PHP 7。可失败分配接口涉及的调用方按旧版本实际结构适配，而不是仅更换函数名。

这是一份**非 PHP 官方发行的源码移植候选版**。代码映射和编译成功不等于独立安全审计认证，不能承诺没有其他缺陷。没有安装到现有 phpStudy、服务器或 IIS，也没有重启现有服务。

构建与文件：

- 使用 VC15 NTS x64 工具链；优化构建为 `/O2 /Ob2`，保留旧 VC15 的 `/d2SSAOptimizer-` 编译器兼容参数。
- `php-7.3.4-official-fix-backport-UNOFFICIAL.patch` 是对干净 PHP 7.3.4 的合并源码补丁。
- `patched-source/` 是本次实际构建的更改文件，`source-changes.json` 保存原文件和修改后文件的 SHA-256。
- `python apply_source_patch.py --source C:\lab\php-7.3.4` 校验所有输入后，对独立的干净源码目录应用这些更改。也提供相同内容的 `git apply` 补丁。应用结果与本次构建输入逐文件核对。
- 原始源码包 SHA-256：`6fe79fa1f8655f98ef6708cde8751299796d6c1e225081011f4104625b923b83`。
- `run-build.cmd` 记录本机构建路径；在其他机器需调整 VC、SDK、依赖和旧 PHP 构建工具路径。使用 `configure` 后再 `build-optimized`。
- 运行包是完整 PHP 目录；应配套使用同次构建的核心和内置扩展，不应随意混用单个 DLL。第三方扩展仍须匹配 PHP 7.3 NTS VC15 x64。
- `logs/` 保存构建、源码审查及执行记录；源码证据包保留最初补丁套用的拒绝记录，用最终合并补丁和逐文件哈希复现结果。

实际执行宿主为 Windows 11 Pro 10.0.26200；**尚未在 Windows Server 2019 / IIS / 目标 ThinkPHP 业务上执行验证**。本地已检查核心、常用内置扩展、已有第三方扩展的加载，以及原生 FastCGI 的请求、上传和 OOM 后续请求行为。第三方扩展“能加载”不代表它们的全部内存超限路径已改造。

官方 PHP 8 用例的比较记录不是完整官方测试框架。PHP 7 与 PHP 8 的语言/API 差异、原有输出差异和宿主执行时间限制会造成不匹配，逐项结果保留在报告中，不把它们包装成全部通过。没有进行独立利用回归认证或内存检查器审计。捆绑的历史依赖也没有因此获得其他安全问题的全面修复。

运行时行为：普通软内存超限尽量结束当前请求并保留工作进程；达到硬限制时仍按官方设计退出工作进程。`memory_hard_limit_percent=-1` 使用官方默认余量，指定百分比须为至少 100。它不能保证任何错误都保留进程。

参考：[PHP 官方源码修复](https://github.com/php/php-src/commit/01a40e89fbfc499936e3b05888d8f00bfde886df)。
